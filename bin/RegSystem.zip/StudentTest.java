import static org.junit.Assert.*;

import org.junit.Test;

public class StudentTest extends Student{

	@Test
	public void test() {
		
		Student s  = new Student();
		Course c = new Course();
		Course d = new Course();
		Course e = new Course();
		assertEquals(0, studentCourseCount(s));
		
		s.addCourse(c);
		assertEquals(1, studentCourseCount(s));
		
		s.dropCourse(c);
		assertEquals(0, studentCourseCount(s));
		
		s.addCourse(d);
		s.addCourse(e);
		assertEquals(2, studentCourseCount(s));
		
		s.dropCourse(d);
		assertEquals(1, studentCourseCount(s));
		
	}

}
